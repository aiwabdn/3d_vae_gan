import pytest
from keras.utils.test_utils import layer_test, keras_test
from keras_contrib.layers import noise


if __name__ == '__main__':
    pytest.main([__file__])
