import pytest
from keras.utils.test_utils import layer_test, keras_test
from keras.layers.embeddings import Embedding
import keras.backend as K
import keras_contrib.backend as KC


if __name__ == '__main__':
    pytest.main([__file__])
